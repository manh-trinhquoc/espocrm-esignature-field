<?php

namespace Espo\Modules\EsignatureField\Htmlizer;

class CustomHtmlizer extends \Espo\Core\Htmlizer\Htmlizer
{
}
